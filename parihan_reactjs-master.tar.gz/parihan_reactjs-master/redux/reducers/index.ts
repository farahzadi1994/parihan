import {combineReducers} from 'redux';


const reducers = combineReducers({
   
});

export type State = ReturnType<typeof reducers>;

export default reducers;
