export const BaseUrls = {
    AppName: 'همکار',
    FrontEndUrl: 'http://localhost:3000',
    BackEndUrl: 'http://192.168.1.111:8006',
};
